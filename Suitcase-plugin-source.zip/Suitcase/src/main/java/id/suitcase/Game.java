package id.suitcase;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Chest;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class Game {

    enum Phase { LOOK, DISCUSS, VOTE, FINAL_DISCUSS, FINAL_DECIDE, ENDED }

    static class Box {
        final Block block;
        final Location stand;
        UUID owner;

        Box(Block block, Location stand) {
            this.block = block;
            this.stand = stand;
        }
    }

    static class VoteHolder implements InventoryHolder {
        Inventory inv;
        final Map<Integer, UUID> slots = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private static final int PAPER_SLOT = 13;

    private final SuitcasePlugin plugin;
    private final UUID hostId;
    private final Location center;
    private final Random rnd = new Random();

    private final List<Box> boxes = new ArrayList<>();
    private final Map<String, Box> byKey = new HashMap<>();
    private final Set<UUID> participants = new LinkedHashSet<>();
    private final Set<UUID> alive = new LinkedHashSet<>();
    private final Map<UUID, GameMode> oldModes = new HashMap<>();
    private final Map<Location, BlockData> originals = new LinkedHashMap<>();
    private final Map<UUID, UUID> votes = new HashMap<>();
    private final Map<UUID, Boolean> decisions = new HashMap<>();
    private Set<UUID> candidates = new LinkedHashSet<>();
    private boolean revoted;
    private Box winnerBox;
    private Phase phase = Phase.LOOK;
    private int timer;
    private BukkitTask task;
    private boolean cleaned;
    private final Events events = new Events();

    Game(SuitcasePlugin plugin, Player host, List<Player> players) {
        this.plugin = plugin;
        this.hostId = host.getUniqueId();
        this.center = host.getLocation().clone();
        participants.add(hostId);

        List<Player> list = new ArrayList<>(players);
        Collections.shuffle(list, rnd);
        buildBoxes(list);
    }

    // ---------------------------------------------------------------- setup

    private void buildBoxes(List<Player> players) {
        int n = players.size();
        int radius = Math.max(5, (int) Math.ceil(n / Math.PI) + 3);
        World w = center.getWorld();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();

        for (int i = 0; i < n; i++) {
            double th = 2 * Math.PI * i / n;
            double cos = Math.cos(th);
            double sin = Math.sin(th);

            Block chest = w.getBlockAt(cx + (int) Math.round(radius * cos), cy, cz + (int) Math.round(radius * sin));
            Block stand = w.getBlockAt(cx + (int) Math.round((radius + 1.6) * cos), cy,
                    cz + (int) Math.round((radius + 1.6) * sin));

            prepareSpot(chest);
            prepareSpot(stand);

            BlockFace face;
            if (Math.abs(cos) > Math.abs(sin)) {
                face = cos > 0 ? BlockFace.EAST : BlockFace.WEST;
            } else {
                face = sin > 0 ? BlockFace.SOUTH : BlockFace.NORTH;
            }
            Chest data = (Chest) Bukkit.createBlockData(Material.CHEST);
            data.setFacing(face);
            chest.setBlockData(data, false);

            double dx = chest.getX() - stand.getX();
            double dz = chest.getZ() - stand.getZ();
            float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            Location loc = new Location(w, stand.getX() + 0.5, stand.getY(), stand.getZ() + 0.5, yaw, 25f);

            Box box = new Box(chest, loc);
            box.owner = players.get(i).getUniqueId();
            boxes.add(box);
            byKey.put(key(chest), box);
        }

        for (Player p : players) {
            participants.add(p.getUniqueId());
            alive.add(p.getUniqueId());
        }
    }

    /** Kosongkan ruang di atas titik, dan beri lantai jika kosong. */
    private void prepareSpot(Block b) {
        Block floor = b.getRelative(BlockFace.DOWN);
        if (!floor.getType().isSolid()) {
            record(floor);
            floor.setType(Material.STONE_BRICKS, false);
        }
        Block up = b.getRelative(BlockFace.UP);
        record(up);
        up.setType(Material.AIR, false);
        record(b);
        b.setType(Material.AIR, false);
    }

    private void record(Block b) {
        originals.putIfAbsent(b.getLocation(), b.getBlockData());
    }

    void begin() {
        Bukkit.getPluginManager().registerEvents(events, plugin);

        for (Box box : boxes) {
            Player p = Bukkit.getPlayer(box.owner);
            if (p == null) {
                continue;
            }
            oldModes.put(p.getUniqueId(), p.getGameMode());
            p.setGameMode(GameMode.ADVENTURE);
            p.teleport(box.stand);
        }

        distribute();
        bc("&aGame dimulai! &7" + alive.size() + " pemain. Host berada di tengah.");
        bc("&7Aturan: dilarang membuka box orang lain. Saat sisa 2 pemain, membuka box = tereliminasi.");
        startRound();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    // ---------------------------------------------------------------- helpers

    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
    }

    private void bc(String s) {
        Component m = c("&6[Suitcase] &r" + s);
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.sendMessage(m);
            }
        }
    }

    private String name(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "?" : n;
    }

    private String key(Block b) {
        return b.getWorld().getName() + ":" + b.getX() + ":" + b.getY() + ":" + b.getZ();
    }

    private Inventory invOf(Box b) {
        return ((org.bukkit.block.Chest) b.block.getState()).getBlockInventory();
    }

    private Box boxFor(UUID owner) {
        for (Box b : boxes) {
            if (owner.equals(b.owner)) {
                return b;
            }
        }
        return null;
    }

    private boolean isBox(Inventory inv) {
        Location l = inv.getLocation();
        return l != null && byKey.containsKey(key(l.getBlock()));
    }

    private ItemStack paper(boolean win) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("Kertas", NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false));
        String text = win ? plugin.getConfig().getString("win-text", "&6SELAMAT!") : "&7(kosong)";
        m.lore(List.of(c(text).decoration(TextDecoration.ITALIC, false)));
        it.setItemMeta(m);
        return it;
    }

    private void distribute() {
        List<Box> list = new ArrayList<>(boxes);
        int w = rnd.nextInt(list.size());
        for (int i = 0; i < list.size(); i++) {
            Inventory inv = invOf(list.get(i));
            inv.clear();
            inv.setItem(PAPER_SLOT, paper(i == w));
        }
        winnerBox = list.get(w);
    }

    private void shuffleOwners() {
        List<UUID> list = new ArrayList<>(alive);
        Collections.shuffle(list, rnd);
        for (int i = 0; i < boxes.size() && i < list.size(); i++) {
            Box b = boxes.get(i);
            b.owner = list.get(i);
            Player p = Bukkit.getPlayer(b.owner);
            if (p != null) {
                p.teleport(b.stand);
            }
        }
    }

    // ---------------------------------------------------------------- phases

    private String label() {
        return switch (phase) {
            case LOOK -> "Lihat box";
            case DISCUSS -> "Diskusi";
            case VOTE -> "Vote";
            case FINAL_DISCUSS -> "Diskusi final";
            case FINAL_DECIDE -> "Tukar / Tetap";
            case ENDED -> "Selesai";
        };
    }

    private void tick() {
        if (phase == Phase.ENDED) {
            return;
        }
        Component bar = c("&e" + label() + " &7- &f" + timer + "s");
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.sendActionBar(bar);
            }
        }
        timer--;
        if (timer <= 0) {
            advance();
        }
    }

    private void advance() {
        switch (phase) {
            case LOOK -> toDiscuss();
            case DISCUSS -> toVote();
            case VOTE -> tally();
            case FINAL_DISCUSS -> toFinalDecide();
            case FINAL_DECIDE -> resolveFinal();
            default -> { }
        }
    }

    private void startRound() {
        phase = Phase.LOOK;
        timer = plugin.getConfig().getInt("look-seconds", 20);
        revoted = false;
        bc("&aSemua pemain: buka box kalian dan lihat isi kertasnya sekarang!");
    }

    private void toDiscuss() {
        phase = Phase.DISCUSS;
        timer = plugin.getConfig().getInt("discuss-seconds", 180);
        bc("&bDiskusi dimulai! Boleh jujur atau berbohong soal kertas kalian.");
    }

    private void toVote() {
        phase = Phase.VOTE;
        timer = plugin.getConfig().getInt("vote-seconds", 30);
        votes.clear();
        revoted = false;
        candidates = new LinkedHashSet<>(alive);
        bc("&cWaktunya VOTE! Siapa pemegang kertas asli? (ketik /suitcase vote kalau menu tertutup)");
        openVotes();
    }

    private void openVotes() {
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && !votes.containsKey(id)) {
                openVoteGui(p);
            }
        }
    }

    private void openVoteGui(Player p) {
        VoteHolder holder = new VoteHolder();
        List<UUID> shown = new ArrayList<>();
        for (UUID id : candidates) {
            if (!id.equals(p.getUniqueId()) && alive.contains(id)) {
                shown.add(id);
            }
        }
        int size = Math.min(54, Math.max(9, ((shown.size() + 8) / 9) * 9));
        Inventory inv = Bukkit.createInventory(holder, size, Component.text("Vote pemegang kertas asli"));
        holder.inv = inv;
        for (int i = 0; i < shown.size() && i < size; i++) {
            UUID id = shown.get(i);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta m = (SkullMeta) head.getItemMeta();
            m.setOwningPlayer(Bukkit.getOfflinePlayer(id));
            m.displayName(Component.text(name(id), NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false));
            head.setItemMeta(m);
            inv.setItem(i, head);
            holder.slots.put(i, id);
        }
        p.openInventory(inv);
    }

    void reopenVote(Player p) {
        if (phase == Phase.VOTE && alive.contains(p.getUniqueId()) && !votes.containsKey(p.getUniqueId())) {
            openVoteGui(p);
        }
    }

    private void castVote(Player voter, UUID target) {
        UUID id = voter.getUniqueId();
        if (phase != Phase.VOTE || !alive.contains(id)) {
            return;
        }
        if (votes.containsKey(id)) {
            voter.sendMessage(c("&cKamu sudah vote."));
            return;
        }
        if (id.equals(target)) {
            voter.sendMessage(c("&cTidak bisa vote diri sendiri."));
            return;
        }
        if (!candidates.contains(target) || !alive.contains(target)) {
            voter.sendMessage(c("&cPemain itu tidak bisa dipilih."));
            return;
        }
        votes.put(id, target);
        voter.closeInventory();
        voter.sendMessage(c("&aVote kamu tercatat."));
        bc("&7" + voter.getName() + " sudah vote (" + votes.size() + "/" + alive.size() + ")");
        if (votes.size() >= alive.size()) {
            tally();
        }
    }

    private void closeVoteGuis() {
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.getOpenInventory().getTopInventory().getHolder() instanceof VoteHolder) {
                p.closeInventory();
            }
        }
    }

    private void tally() {
        if (phase != Phase.VOTE) {
            return;
        }
        closeVoteGuis();

        Map<UUID, Integer> count = new LinkedHashMap<>();
        for (UUID cnd : candidates) {
            count.put(cnd, 0);
        }
        for (Map.Entry<UUID, UUID> v : votes.entrySet()) {
            if (alive.contains(v.getKey()) && count.containsKey(v.getValue())) {
                count.merge(v.getValue(), 1, Integer::sum);
            }
        }

        StringBuilder sb = new StringBuilder("&eHasil vote: ");
        for (Map.Entry<UUID, Integer> e : count.entrySet()) {
            sb.append("&f").append(name(e.getKey())).append(" &7(").append(e.getValue()).append(") ");
        }
        bc(sb.toString());

        int max = 0;
        for (int v : count.values()) {
            max = Math.max(max, v);
        }
        List<UUID> top = new ArrayList<>();
        for (Map.Entry<UUID, Integer> e : count.entrySet()) {
            if (e.getValue() == max) {
                top.add(e.getKey());
            }
        }

        UUID target;
        if (max == 0) {
            target = top.get(rnd.nextInt(top.size()));
            bc("&7Tidak ada yang vote, dipilih acak.");
        } else if (top.size() > 1) {
            if (!revoted) {
                revoted = true;
                candidates = new LinkedHashSet<>(top);
                votes.clear();
                timer = plugin.getConfig().getInt("vote-seconds", 30);
                bc("&cSeri! Vote ulang antara yang seri saja.");
                openVotes();
                return;
            }
            target = top.get(rnd.nextInt(top.size()));
            bc("&7Masih seri, dipilih acak di antara yang seri.");
        } else {
            target = top.get(0);
        }
        resolve(target);
    }

    private void resolve(UUID target) {
        UUID holder = winnerBox.owner;
        if (target.equals(holder)) {
            bc("&a" + name(target) + " ternyata memegang kertas ASLI!");
            win(target);
            return;
        }
        bc("&c" + name(target) + " memegang kertas KOSONG dan tereliminasi!");
        eliminate(target, "kalah vote");

        if (alive.size() <= 2) {
            startFinal();
        } else {
            shuffleOwners();
            distribute();
            bc("&7Host mengacak posisi dan membagikan ulang kertas.");
            startRound();
        }
    }

    private void eliminate(UUID id, String why) {
        alive.remove(id);
        Box b = boxFor(id);
        if (b != null) {
            invOf(b).clear();
            BlockData orig = originals.get(b.block.getLocation());
            b.block.setBlockData(orig != null ? orig : Material.AIR.createBlockData(), false);
            boxes.remove(b);
            byKey.remove(key(b.block));
        }
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            p.closeInventory();
            p.setGameMode(GameMode.SPECTATOR);
        }
        bc("&c" + name(id) + " tereliminasi (" + why + ").");
    }

    // ---------------------------------------------------------------- final

    private void startFinal() {
        shuffleOwners();
        phase = Phase.FINAL_DISCUSS;
        timer = plugin.getConfig().getInt("final-discuss-seconds", 60);
        decisions.clear();
        bc("&6FINAL! Tersisa 2 pemain. Dilarang membuka box, yang membuka akan tereliminasi.");
        bc("&6Diskusikan: pertahankan box atau tukar? Pemegang kertas asli menang.");
    }

    private void toFinalDecide() {
        phase = Phase.FINAL_DECIDE;
        timer = plugin.getConfig().getInt("final-decide-seconds", 20);
        decisions.clear();
        Component msg = c("&eBox akan ditukar hanya jika KEDUANYA memilih tukar: ")
                .append(c("&a&l[TUKAR]").clickEvent(ClickEvent.runCommand("/suitcase tukar")))
                .append(c(" "))
                .append(c("&c&l[TETAP]").clickEvent(ClickEvent.runCommand("/suitcase tetap")));
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.sendMessage(msg);
            }
        }
        bc("&7Menunggu keputusan kedua pemain...");
    }

    void decide(Player p, boolean swap) {
        UUID id = p.getUniqueId();
        if (phase != Phase.FINAL_DECIDE || !alive.contains(id)) {
            return;
        }
        if (decisions.containsKey(id)) {
            p.sendMessage(c("&cKamu sudah memilih."));
            return;
        }
        decisions.put(id, swap);
        p.sendMessage(c("&aPilihan kamu tercatat."));
        if (decisions.size() >= alive.size()) {
            resolveFinal();
        }
    }

    private void resolveFinal() {
        if (phase != Phase.FINAL_DECIDE) {
            return;
        }
        boolean both = true;
        for (UUID id : alive) {
            if (!decisions.getOrDefault(id, false)) {
                both = false;
            }
        }
        if (both && boxes.size() == 2) {
            Box a = boxes.get(0);
            Box b = boxes.get(1);
            Inventory ia = invOf(a);
            Inventory ib = invOf(b);
            ItemStack pa = ia.getItem(PAPER_SLOT);
            ItemStack pb = ib.getItem(PAPER_SLOT);
            ia.setItem(PAPER_SLOT, pb);
            ib.setItem(PAPER_SLOT, pa);
            winnerBox = (winnerBox == a) ? b : a;
            bc("&eKedua pemain sepakat: box DITUKAR!");
        } else {
            bc("&eBox tidak ditukar.");
        }
        for (Box b : boxes) {
            bc("&7Box " + name(b.owner) + " berisi kertas " + (b == winnerBox ? "&aASLI" : "&cKOSONG"));
        }
        win(winnerBox.owner);
    }

    // ---------------------------------------------------------------- end

    private void win(UUID id) {
        phase = Phase.ENDED;
        if (task != null) {
            task.cancel();
        }
        bc("&a&l" + name(id) + " MENANG! &r&7Box akan dihapus dalam 10 detik.");
        Bukkit.getScheduler().runTaskLater(plugin, this::cleanup, 200L);
    }

    void cleanup() {
        if (cleaned) {
            return;
        }
        cleaned = true;
        phase = Phase.ENDED;
        if (task != null) {
            task.cancel();
        }
        HandlerList.unregisterAll(events);

        for (Box b : boxes) {
            invOf(b).clear();
        }
        for (Map.Entry<Location, BlockData> e : originals.entrySet()) {
            e.getKey().getBlock().setBlockData(e.getValue(), false);
        }
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            GameMode old = oldModes.get(id);
            if (p != null && old != null) {
                p.setGameMode(old);
            } else if (p != null && !id.equals(hostId)) {
                p.setGameMode(GameMode.SURVIVAL);
            }
        }
        plugin.clear(this);
    }

    // ---------------------------------------------------------------- events

    private class Events implements Listener {

        @EventHandler
        public void onMove(PlayerMoveEvent e) {
            if (e instanceof PlayerTeleportEvent) {
                return;
            }
            if (phase == Phase.ENDED || !alive.contains(e.getPlayer().getUniqueId())) {
                return;
            }
            Location f = e.getFrom();
            Location t = e.getTo();
            if (t == null) {
                return;
            }
            if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
                e.setTo(new Location(f.getWorld(), f.getX(), f.getY(), f.getZ(), t.getYaw(), t.getPitch()));
            }
        }

        @EventHandler
        public void onOpen(InventoryOpenEvent e) {
            if (!(e.getPlayer() instanceof Player p)) {
                return;
            }
            Location l = e.getInventory().getLocation();
            if (l == null) {
                return;
            }
            Box b = byKey.get(key(l.getBlock()));
            if (b == null) {
                return;
            }
            UUID id = p.getUniqueId();
            if (id.equals(hostId) || phase == Phase.ENDED) {
                return;
            }
            if (!alive.contains(id)) {
                e.setCancelled(true);
                return;
            }
            if (phase == Phase.FINAL_DISCUSS || phase == Phase.FINAL_DECIDE) {
                e.setCancelled(true);
                eliminate(id, "membuka box saat final");
                if (alive.size() == 1) {
                    win(alive.iterator().next());
                }
                return;
            }
            if (!id.equals(b.owner)) {
                e.setCancelled(true);
                p.sendMessage(c("&cIni bukan box kamu!"));
            }
        }

        @EventHandler
        public void onClick(InventoryClickEvent e) {
            Inventory top = e.getView().getTopInventory();
            if (top.getHolder() instanceof VoteHolder h) {
                e.setCancelled(true);
                if (e.getClickedInventory() == top && e.getWhoClicked() instanceof Player p) {
                    UUID target = h.slots.get(e.getSlot());
                    if (target != null) {
                        castVote(p, target);
                    }
                }
                return;
            }
            if (isBox(top)) {
                e.setCancelled(true);
            }
        }

        @EventHandler
        public void onDrag(InventoryDragEvent e) {
            Inventory top = e.getView().getTopInventory();
            if (top.getHolder() instanceof VoteHolder || isBox(top)) {
                e.setCancelled(true);
            }
        }

        @EventHandler
        public void onBreak(BlockBreakEvent e) {
            if (byKey.containsKey(key(e.getBlock())) && !e.getPlayer().getUniqueId().equals(hostId)) {
                e.setCancelled(true);
            }
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent e) {
            UUID id = e.getPlayer().getUniqueId();
            if (id.equals(hostId)) {
                Bukkit.getScheduler().runTask(plugin, Game.this::cleanup);
                return;
            }
            if (!alive.contains(id) || phase == Phase.ENDED) {
                return;
            }
            Box removed = boxFor(id);
            eliminate(id, "keluar dari server");
            candidates.remove(id);
            votes.remove(id);

            if (phase == Phase.FINAL_DISCUSS || phase == Phase.FINAL_DECIDE) {
                if (alive.size() == 1) {
                    win(alive.iterator().next());
                }
                return;
            }
            if (alive.size() < 3) {
                bc("&cPemain kurang, game dihentikan.");
                Bukkit.getScheduler().runTask(plugin, Game.this::cleanup);
                return;
            }
            if (removed != null && removed == winnerBox) {
                distribute();
                bc("&7Pemegang kertas asli keluar, kertas dibagikan ulang.");
            }
        }
    }
}
